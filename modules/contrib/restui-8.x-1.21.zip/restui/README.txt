REST UI
=======

This module provides a user interface to manage REST resources.

Installation
============

Once the module has been installed, navigate to admin/config/services/rest
(Configuration > Web Services > REST through the administration panel) and
configure the available resources.
